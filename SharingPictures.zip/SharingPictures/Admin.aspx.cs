﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SharingPictures
{
    public partial class Admin : System.Web.UI.Page
    {
        string connStr = WebConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            GridView1.DataSource = User();
            GridView1.DataBind();
        }
        public DataTable User()
        {
            SqlConnection sc = new SqlConnection();
            sc.Open();
            SqlCommand cmd = new SqlCommand("select * from Users", sc);
            DataTable dt = new DataTable();
            SqlDataReader sr = cmd.ExecuteReader();
            dt.Load(sr);
            sc.Close();
            return dt;

        }

        protected void Add_Click(object sender, EventArgs e)
        {




            SqlConnection con = new SqlConnection(connStr);
            string query = "INSERT INTO dbo.Users (@UserName,@Password,@Email)";

            // string query = "INSERT INTO dbo.Users (UserName,Password,Email) VALUES (" + TextBox1.Text
            //   + ",'" + TextBox2.Text + "','" + TextBox3.Text + "')";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("UserName", Username.Text);
            cmd.Parameters.AddWithValue("Password", Password.Text);
            cmd.Parameters.AddWithValue("Email", Email.Text);


            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }

        protected void Delete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(connStr);
            string query = "DELETE dbo.Users WHERE UserName = '" + TextBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }

        protected void Edit_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(connStr);
            string query = "UPDATE dbo.Users set Password = @Password, Email = @Email WHERE UserName = @UserName";
            //string query = "UPDATE dbo.Users (UserName,Password,Email) VALUES (" + TextBox1.Text
            //      + ",'" + TextBox2.Text + "','" + TextBox3.Text + "')";
            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("UserName", Username.Text);
            cmd.Parameters.AddWithValue("Password", Password.Text);
            cmd.Parameters.AddWithValue("Email", Email.Text);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }
    }
}