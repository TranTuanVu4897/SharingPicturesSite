﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SharingPictures
{
    public partial class DetailPicture : System.Web.UI.Page
    {
        string connStr = WebConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["login"] == null)
            {
                btnUser.Visible = false;
                btnUpload.Visible = false;
                btnLogin.Visible = true;
                btnRegister.Visible = true;
                btnLogout.Visible = false;
            }
            else if (Session["login"].ToString().Equals("0"))
            {
                btnUser.Visible = false;
                btnUpload.Visible = false;
                btnLogin.Visible = true;
                btnRegister.Visible = true;
                btnLogout.Visible = false;
            }
            else if (Session["login"].ToString().Equals("1"))
            {
                btnLogin.Visible = false;
                btnRegister.Visible = false;
                btnUser.Visible = true;
                btnUpload.Visible = true;
                btnLogout.Visible = true;

            }
            else if (Session["login"].ToString().Equals("2"))
            {
                btnLogin.Visible = false;
                btnRegister.Visible = false;
                btnUser.Visible = true;
                btnUpload.Visible = true;
                btnLogout.Visible = true;

            }
            lblNotice.Visible = false;
            if (Session["DetailPicture"] != null)
            {
                btnLike.Visible = true;
                btnDis.Visible = true;
                btnFavorite.Visible = true;
                load_data();
            }else
            {
                btnLike.Visible = false;
                btnDis.Visible = false;
                btnFavorite.Visible = false;
                lblNotice.Visible = true;
                lblNotice.Text = "NO THING TO DISPLAY";
            }
        }

        private void load_data()
        {
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from images where imageName like '" + Session["DetailPicture"].ToString() + "'", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lblTitle.Text = dt.Rows[0]["Title"].ToString();
            imgPic.ImageUrl = dt.Rows[0]["ImageName"].ToString();
            lblLike.Text = dt.Rows[0]["UpPoint"].ToString();
            lblDis.Text = dt.Rows[0]["DownPoint"].ToString();
            lblPoint.Text = dt.Rows[0]["Point"].ToString();
            conn.Close();
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("Register.aspx");
        }

        protected void btnUser_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("RegistedUser.aspx");
        }

        protected void btnUpload_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void btnHomePage_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {

            Session.Clear();
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }
    }
}