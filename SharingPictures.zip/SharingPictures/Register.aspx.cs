﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SharingPictures
{
    public partial class Register : System.Web.UI.Page
    {
        string connStr = WebConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            lblNotice.Visible = false;
        }

        protected void btnHomePage_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (txtUser.Text == null || txtPass.Text == null || txtMail.Text == null)
            {
                lblNotice.Visible = true;
                lblNotice.Text = "Please fill all information";
            }
            else
            {
                SqlConnection conn = new SqlConnection(connStr);
                conn.Open();
                SqlCommand check = new SqlCommand("select * from users where userName='" + txtUser.Text + "' or email = '" + txtMail.Text + "'", conn);
                SqlDataAdapter da = new SqlDataAdapter(check);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    lblNotice.Visible = true;
                    lblNotice.Text = "Username or Email have been exist.";
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("insert into users values(@user,@pass,@mail,@status,@sex,@about,@role)", conn);
                    cmd.Parameters.AddWithValue("@user", txtUser.Text);
                    cmd.Parameters.AddWithValue("@pass", txtPass.Text);
                    cmd.Parameters.AddWithValue("@mail", txtMail.Text);
                    cmd.Parameters.AddWithValue("@status", 1);
                    cmd.Parameters.AddWithValue("@sex", radioSex.SelectedItem.Value.ToString());
                    cmd.Parameters.AddWithValue("@about", "");
                    cmd.Parameters.AddWithValue("@role", 2);

                    cmd.ExecuteNonQuery();
                }
                conn.Close();
            }
        }
    }
}