﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SharingPictures
{
    public partial class GalleryDetail : System.Web.UI.Page
    {
        string connStr = WebConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            load_data();
            
        }

        private void load_data()
        {
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from images where galleryid = '" + Session["gallery"].ToString() + "' and uploader = '" + Session["user"].ToString() + "' order by createddate desc", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            DataList1.DataSource = dt;
            DataList1.DataBind();
            conn.Close();
        }

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            Session["DetailPicture"] = ((ImageButton)DataList1.SelectedItem.FindControl("imgPic")).ImageUrl;
            Response.Redirect("DetailPicture.aspx");
        }

        protected void btnHomePage_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void imgPic_Click(object sender, ImageClickEventArgs e)
        {
            Session["DetailPicture"] = ((ImageButton)sender).ImageUrl;
            Response.Redirect("DetailPicture.aspx");
        }
    }
}