﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SharingPictures
{
    public partial class HomePage : System.Web.UI.Page
    {
        string connStr = WebConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
        static int currentposition = 0;
        static int totalrows = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            Session["sort"] = "point";

            if (Session["login"] == null)
            {
                btnUser.Visible = false;
                btnUpload.Visible = false;
                btnLogin.Visible = true;
                btnRegister.Visible = true;
                btnLogout.Visible = false;
            }
            else if (Session["login"].ToString().Equals("0"))
            {
                btnUser.Visible = false;
                btnUpload.Visible = false;
                btnLogin.Visible = true;
                btnRegister.Visible = true;
                btnLogout.Visible = false;
            }
            else if (Session["login"].ToString().Equals("1"))
            {
                btnLogin.Visible = false;
                btnRegister.Visible = false;
                btnUser.Visible = true;
                btnUpload.Visible = true;
                btnLogout.Visible = true;

            }
            else if (Session["login"].ToString().Equals("2"))
            {
                btnLogin.Visible = false;
                btnRegister.Visible = false;
                btnUser.Visible = true;
                btnUpload.Visible = true;
                btnLogout.Visible = true;

            }

            lblNotice.Visible = false;

            if (!IsPostBack)
            {
                load_data("");
            }
        }

        protected void btnUser_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["login"].ToString().Equals("2"))
            {
                Response.Redirect("RegistedUser.aspx");
            }
            else
            {
                Response.Redirect("Admin.aspx");
            }
        }

        private void load_data(string condition)
        {
            SqlConnection conn = new SqlConnection(connStr);

            conn.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter("Select * from Images " + condition + " order by " + Session["sort"].ToString() + " desc", conn);
            da.Fill(ds);
            totalrows = ds.Tables[0].Rows.Count;
            if (totalrows > 0)
            {
                DataTable dt = ds.Tables[0];
                PagedDataSource page = new PagedDataSource();
                page.DataSource = dt.DefaultView;
                page.AllowPaging = true;
                page.CurrentPageIndex = currentposition;
                page.PageSize = 20;
                btnEnd.Enabled = !page.IsLastPage;
                btnNext.Enabled = !page.IsLastPage;
                btnFirst.Enabled = !page.IsFirstPage;
                btnPrev.Enabled = !page.IsFirstPage;
                listPictures.DataSource = page;
                listPictures.DataBind();

                lblNotice.Visible = false;
            }
            else
            {
                listPictures.DataBind();
                lblNotice.Text = "Nothing to display";
                lblNotice.Visible = true;
            }

            conn.Close();
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("Register.aspx");

        }

        protected void btnSearch_Click(object sender, ImageClickEventArgs e)
        {
            load_data(" where title like '%" + txtSearch.Text + "%' ");
        }



        protected void btnTop_Click(object sender, ImageClickEventArgs e)
        {
            Session["sort"] = "point";
        }

        protected void btnNew_Click(object sender, ImageClickEventArgs e)
        {
            Session["sort"] = "createdtime";
        }

        protected void btnFirst_Click(object sender, ImageClickEventArgs e)
        {
            currentposition = 0;
            load_data("");
        }

        protected void btnPrev_Click(object sender, ImageClickEventArgs e)
        {

            if (currentposition == 0)
            {

            }
            else
            {
                currentposition = currentposition - 1;
                load_data("");
            }
        }

        protected void btnNext_Click(object sender, ImageClickEventArgs e)
        {

            if (currentposition == totalrows - 1)
            {

            }
            else
            {
                currentposition = currentposition + 1;
                load_data("");
            }
        }

        protected void btnEnd_Click(object sender, ImageClickEventArgs e)
        {
            currentposition = totalrows - 1;
            load_data("");
        }

        protected void imgPic_Click(object sender, ImageClickEventArgs e)
        {
            Session["DetailPicture"] = ((ImageButton)sender).ImageUrl;
            Response.Redirect("DetailPicture.aspx");
        }

        protected void listPictures_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (Session["login"] != null)
            {
                if (!Session["login"].ToString().Equals("0"))
                {
                    string user = "[" + Session["user"].ToString() + "]";
                    listPictures.SelectedIndex = e.Item.ItemIndex;
                    string url = ((ImageButton)listPictures.SelectedItem.FindControl("imgPic")).ImageUrl;
                    SqlConnection conn = new SqlConnection(connStr);
                    conn.Open();
                    SqlDataAdapter da = new SqlDataAdapter("select * from images where imagename = '" + url + "'", conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    string upVote = dt.Rows[0]["UpVote"].ToString();
                    string downVote = dt.Rows[0]["DownVOte"].ToString();
                    int upPoint = Int32.Parse(dt.Rows[0]["UpPoint"].ToString());
                    int downPoint = Int32.Parse(dt.Rows[0]["DownPoint"].ToString());


                    if (e.CommandName == "cmdLike")
                    {
                        if (!upVote.Contains(user))
                        {
                            SqlConnection conn2 = new SqlConnection(connStr);
                            SqlCommand cmd = new SqlCommand("update images set point = @point, downPoint = @downP, upPoint = @upP, upVote = @upVote, DownVote = @downVote  where imageName = '" + url + "'", conn);

                            upPoint++;
                            upVote = upVote + user;
                            if (downVote.Contains(user))
                            {
                                downVote = downVote.Replace(user, "");
                                downPoint--;
                            }

                            int point = upPoint - downPoint;
                            if (point < 0)
                            {
                                point = 0;
                            }

                            cmd.Parameters.AddWithValue("@point", point);
                            cmd.Parameters.AddWithValue("@downP", downPoint);
                            cmd.Parameters.AddWithValue("@upP", upPoint);
                            cmd.Parameters.AddWithValue("@upVote", upVote);
                            cmd.Parameters.AddWithValue("@downVote", downVote);
                            cmd.ExecuteNonQuery();
                            conn2.Close();
                        }
                    }
                    else if (e.CommandName == "cmdDis")
                    {
                        if (!downVote.Contains(user))
                        {
                            SqlConnection conn2 = new SqlConnection(connStr);
                            SqlCommand cmd = new SqlCommand("update images set point = @point, downPoint = @downP, upPoint = @upP, upVote = @upVote, DownVote = @downVote where imageName = '" + url + "'", conn);
                            
                            downPoint++;
                            downVote = downVote + user;
                            if (upVote.Contains(user))
                            {
                                upVote = upVote.Replace(user, "");
                                upPoint--;
                            }

                            int point = upPoint - downPoint;
                            if (point < 0)
                            {
                                point = 0;
                            }

                            cmd.Parameters.AddWithValue("@point", point);
                            cmd.Parameters.AddWithValue("@downP", downPoint);
                            cmd.Parameters.AddWithValue("@upP", upPoint);
                            cmd.Parameters.AddWithValue("@upVote", upVote);
                            cmd.Parameters.AddWithValue("@downVote", downVote);
                            cmd.ExecuteNonQuery();
                            conn2.Close();
                        }
                    }

                    conn.Close();
                    load_data("");
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
            }
            else
            {
                Response.Redirect("Login.aspx");
            }

        }

        protected void btnUpload_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("UploadPage.aspx");
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }
    }
}