﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SharingPictures
{
    public partial class UploadPage : System.Web.UI.Page
    {
        string connStr = WebConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            lblNotice.Visible = false;
        }

        protected void btnHomePage_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void btnUser_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("RegistedUser.aspx");
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            if (txtTile.Text != null)
            {
                lblNotice.Visible = false;
                if (Page.IsValid && FileUpload1.HasFile && CheckFileType(FileUpload1.FileName))
                {
                    string fileName = geneImageName();
                    string filePath = MapPath(fileName);
                    FileUpload1.SaveAs(filePath);
                    imgTest.ImageUrl = fileName;
                    SqlConnection conn = new SqlConnection(connStr);
                    SqlCommand cmd = new SqlCommand("Insert into images values('" + fileName + "',0,NULL,NULL," + listGallery.SelectedItem.Value.ToString() + ",'" + Session["user"].ToString() + "',NULL, '" + DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss") + "',NULL,0,0)", conn);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    RequiredFieldValidator1.Enabled = false;
                }
            }else
            {
                lblNotice.Visible = true;
            }
        }
        bool CheckFileType(string fileName)
        {

            string ext = Path.GetExtension(fileName);
            switch (ext.ToLower())
            {
                case ".gif":
                    return true;
                case ".png":
                    return true;
                case ".jpg":
                    return true;
                case ".jpeg":
                    return true;
                default:
                    return false;
            }
        }
        private string geneImageName()
        {
            bool run = true;
            string imageName = "";
            while (run)
            {
                imageName = "~/img/gallery/" + RandomString(20, false) + Path.GetExtension(FileUpload1.FileName);
                SqlConnection conn = new SqlConnection(connStr);
                SqlDataAdapter sda = new SqlDataAdapter("select * from images where imageName = '" + imageName + "'", conn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    run = false;
                }

            }
            return imageName;

        }

        public string RandomString(int size, bool lowerCase)
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }
            if (lowerCase)
                return builder.ToString().ToLower();
            return builder.ToString();
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }
    }
}