﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SharingPictures
{
    public partial class User : System.Web.UI.Page
    {
        string connStr = WebConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["edit"] = !btnEdit.Visible;
            loadUser();
            loadGallery();
            loadScreen();
        }

        private void loadScreen()
        {
            lblAbout.Visible = !(Boolean)Session["edit"];
            btnEdit.Visible = !(Boolean)Session["edit"];
            txtAbout.Visible = (Boolean)Session["edit"];
            btnEditEnd.Visible = (Boolean)Session["edit"];
        }

        private void loadGallery()
        {
            SqlConnection conn = new SqlConnection(connStr);
            SqlDataAdapter sda = new SqlDataAdapter("select * from galleries where username = '" + Session["user"].ToString() + "'", conn);
            DataTable info = new DataTable();
            sda.Fill(info);
            listGallery.DataSource = info;
            listGallery.DataBind();
            conn.Close();
        }

        private void loadUser()
        {
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from users where username = '"+Session["user"].ToString()+"'", conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            lblEmail.Text = dt.Rows[0]["Email"].ToString();
            lblUser.Text = dt.Rows[0]["UserName"].ToString();
            lblAbout.Text = dt.Rows[0]["About"].ToString();
            conn.Close();

        }

        protected void btnEdit_Click(object sender, ImageClickEventArgs e)
        {
            Session["edit"] = true;
        }

        protected void btnEditEnd_Click(object sender, ImageClickEventArgs e)
        {
            Session["edit"] = false;
            if (txtAbout.Text != null)
            {
                SqlConnection conn = new SqlConnection(connStr);
                SqlCommand cmd = new SqlCommand("Update users about = @about where username = '" + Session["user"].ToString() + "'", conn);
                conn.Open();
                cmd.Parameters.AddWithValue("@about", txtAbout.Text);
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }
        

        protected void btnHomePage_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void imgGallery_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton img = (ImageButton)sender;
            string id = img.ID; //get the ID
            DataListItem item = (DataListItem)img.NamingContainer;
            if (item != null)
            {
                //do something
                //get the index of the Current ImageButton selected
                int itemIndex = item.ItemIndex;
                listGallery.SelectedIndex = itemIndex;
                Session["gallery"] = ((Label)listGallery.SelectedItem.FindControl("lblID")).Text;
            }
            Response.Redirect("DetailGallery.aspx");
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {

            Session.Clear();
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }
    }
}